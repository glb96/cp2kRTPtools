# cp2kRTPtools
Tools to open and work with RTP outputs of chemical package CP2K
